<?php
// cek session
session_start();
if (!isset($_SESSION["login"])) {
  header('Location:index.php');
  exit;
}

// proses mysqli
require 'koneksi.php';
$customer = query("SELECT * FROM db_pelangan ORDER BY id_pelangan DESC LIMIT 8");

if (isset($_POST["submit"])) {
  $customer = cari(htmlspecialchars($_POST["kyword"]));
}

// json
$jeson = file_get_contents('https://api.kawalcorona.com/indonesia/provinsi');
$api = json_decode($jeson, true);
$provinsi = $api[29]["attributes"]["Provinsi"];
$positif = $api[29]["attributes"]["Kasus_Posi"];
$sembuh = $api[29]["attributes"]["Kasus_Semb"];

?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
  <title>Dashboard | User</title>
</head>

<body>

  <!-- awal nav bar -->
  <nav class="navbar navbar-expand-lg navbar-light navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="index.php">ECHO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav ">
          <li class="nav-item active">
            <a class="nav-link ml-lg-5" href="dashboard.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link ml-lg-2" href="#">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link ml-lg-2" href="#">Galery</a>
          </li>
          <li class="nav-item">
            <a class="nav-link ml-lg-2" href="#">Profile</a>
          </li>
          <li class="nav-item">
            <a class="nav-link ml-lg-2 btn btn-outline-secondary btn-sm" href="logout.php" onclick="return confirm('Yakin Inggin Log Out')" ;>Log Out</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- akhir nav bar -->

  <!-- awal carousel -->
  <div class="container">
    <div class="row mt-5">
      <div class="col col-12 col-lg-6 mt-lg-5">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="img/12.jpg" class="d-block w-100 img-thumbnail" alt="...">
            </div>
            <div class="carousel-item">
              <img src="img/13.jpg" class="d-block w-100 img-thumbnail" alt="...">
            </div>
            <div class="carousel-item">
              <img src="img/14.jpg" class="d-block w-100 img-thumbnail" alt="...">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>
      <div class="col col-12 col-lg-5 ml-lg-5 mt-lg-5">
        <section class="text mt-5 ml-3 ml-lg-5">
          <h2>Selamat Datang Di Website Echo Mineral</h2>

          <p class="mt-4">Air higenis dan diproduksi Secara Moderen dan Aman Bagi tubuh</p>
          <a href="tambahData.php" class="btn btn-dark mt-4">Tambah Data</a>
        </section>
      </div>
    </div>
  </div>
  <!-- akhir carausel -->

  <!-- awal -->
  <div class="container">
    <div class="row text-center mt-5">
      <div class="col mt-3">
        <i class="far fa-address-book"></i>
      </div>
      <div class="col">
        <i class="fab fa-app-store"></i>
      </div>
      <div class="col">
        <i class="fas fa-atom"></i>
      </div>
      <div class="col mt-3">
        <i class="fas fa-car-alt w-100"></i>
      </div>
    </div>
  </div>
  <!-- akhir -->


  <!-- awal profile -->
  <div class="container text-center">
    <div class="row">
      <div class="col col-6 mt-5 text-center">
        <form class="form-inline " method="POST" action="">
          <input class="form-control mr-sm-2" type="text" name="kyword" placeholder="Search" aria-label="Search" autofocus autocomplete="off">
          <button class="btn btn-outline-dark my-2 my-sm-0" type="submit" name="submit">Search</button>
        </form>
      </div>
    </div>
    <table class="table table-responsive-sm table-striped table-bordered mt-3">
      <thead class="border border-dark">
        <tr>
          <th scope="col">No</th>
          <th scope="col">Nama</th>
          <th scope="col">Alamat</th>
          <th scope="col">Jumlah Galon</th>
          <th scope="col">Hutang</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $no = 1;
        foreach ($customer as $customers) : ?>
          <tr>
            <th scope="row"><?= $no++ ?></th>
            <td><?= $customers["nama"] ?></td>
            <td><?= $customers["alamat"] ?></td>
            <td><?= $customers["jml_galon"] ?></td>
            <td><?= $customers["hutang"] ?></td>
            <td>
              <div class="row justify-content-center">
                <div class="col">
                  <a href="edit.php?id=<?= $customers["id_pelangan"] ?>" class="btn btn-sm btn-outline-dark">Ubahh </a>
                  <a href="hapus.php?id=<?= $customers["id_pelangan"] ?>" class="btn mt-2 mt-lg-0 btn-sm btn-outline-dark" onclick="return confirm('Yakin Inggin Menghapus')" ;>Hapus</a>
                </div>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <div class="row">
      <div class="col text-center mt-3">
        <hr>
        <p>Akhir Table</p>
        <hr>
      </div>
    </div>
  </div>
  <!-- akhir profile -->

  <!-- awal -->
  <div class="container">
    <div class="row mt-5 mb-4">
      <div class="col mt-4 mt-lg-3">
        <div class="card-deck">
          <div class="card">
            <img src="img/13.jpg" class="card-img-top img-thumbnail" alt="...">
            <div class="card-body">
              <h5 class="card-title">Kangen Water</h5>
            </div>
            <div class="card-footer">
              <small class="text-muted">Air Minum Ini Baik Untuk Kesehatan Tubuh Anda.</small>
            </div>
          </div>
          <div class="card">
            <img src="img/14.jpg" class="card-img-top img-thumbnail" alt="...">
            <div class="card-body">
              <h5 class="card-title">Air Sanggat Jernih</h5>
            </div>
            <div class="card-footer">
              <small class="text-muted">Air Ini Berasal Dari Matai Air Pilihan.</small>
            </div>
          </div>
          <div class="card">
            <img src="img/15.jpg" class="card-img-top img-thumbnail" alt="...">
            <div class="card-body">
              <h5 class="card-title">Produk Kangen Water</h5>
            </div>
            <div class="card-footer">
              <small class="text-muted">Menyediakan Berbagai Produk Kangen Water.</small>
            </div>
          </div>
          <div class="card">
            <img src="img/13.jpg" class="card-img-top img-thumbnail" alt="...">
            <div class="card-body">
              <h5 class="card-title">Sertificat</h5>
            </div>
            <div class="card-footer">
              <small class="text-muted">Depot Kami Sudah Mendapat Pengakuan,Serifikat, atau Pengakuan Dari Dinas Kesehatan Kabupaten Muko Muko.</small>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- akhir -->


  <!-- awal -->
  <div class="container">
    <div class="row mt-lg-5">
      <div class="col col-6 col-md-4 col-lg-3 mt-5 mt-lg-2">
        <h2 class="mt-lg-5">Echo Mineral</h2>
      </div>
      <div class="col col-6 col-md-4 col-lg-3">
        <h4>Kontak</h4>
        <a href="http://">
          <p>Eko Kondim</p>
        </a>
        <a href="http://">
          <p>Angga Pelo</p>
        </a>
        <a href="http://">
          <p>Tejo Supro</p>
        </a>
        <a href="http://">
          <p>Asep pear</p>
        </a>
      </div>
      <div class="col col-6 col-md-4 col-lg-3">
        <h4>Galery</h4>
        <a href="http://">
          <p>Depot galon</p>
        </a>
        <a href="http://">
          <p>Bersih-Bersih Depot</p>
        </a>
        <a href="http://">
          <p>Mobil</p>
        </a>
        <a href="http://">
          <p>Jalan-Jalan</p>
        </a>
        <a href="http://">
          <p>Angota</p>
        </a>
      </div>
      <div class="col col-6 col-md-3 col-lg-3 ">
        <h4>Saran</h4>
        <a href="http://">
          <p>Masukan</p>
        </a>
        <a href="http://">
          <p>Keritiakn</p>
        </a>
        <a href="http://">
          <p>Donasi</p>
        </a>
        <a href="http://">
          <p>Suport</p>
        </a>
      </div>
    </div>
    <div class="row">
      <div class="col mt-sm-0 mt-4 ">
        <hr class="mt-5 border border-dark">
        <!-- <marquee>Ini Merupakan Data Akurat Informasi Update Data Kasus COVID-19 Provinsi = <?= $provinsi; ?>, Kasus Positif = <?= $positif; ?>, Kasus Sembuh = <?= $sembuh;  ?></marquee> -->
      </div>
    </div>
    <div class="row">
      <div class="col text-center mt-2 mb-2">
        <h5>CopyRight@YogiPrayoga.AllReceved.</h5>
      </div>
    </div>

    <!-- akhir -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</body>

</html>