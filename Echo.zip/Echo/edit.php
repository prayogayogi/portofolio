<?php
// cek session
session_start();
if (!isset($_SESSION["login"])) {
  header('Location:index.php');
  exit;
}

// perintah mysqli
require 'koneksi.php';
$id = $_GET["id"];
$query = query("SELECT * FROM db_pelangan WHERE id_pelangan = $id");

// proses edit data
if (isset($_POST["submit"])) {
  $id = $_POST["id_pelangan"];
  $nama = $_POST["nama"];
  $alamat = $_POST["alamat"];
  $jml_galon = $_POST["jml_galon"];
  $hutang = $_POST["hutang"];

  $hasil = data("UPDATE db_pelangan SET nama='$nama', alamat='$alamat', jml_galon='$jml_galon', hutang='$hutang' WHERE id_pelangan =" . $id);
  if ($hasil) {
    header('Location:dashboard.php');
  }
}

?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
  <link rel="stylesheet" href="style.css">
  <title>Edit | Data User</title>
</head>

<body>
  <!-- awal nav bar -->
  <nav class="navbar navbar-expand-lg navbar navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="dashboard.php">ECHO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav">
          <li class="nav-item ">
            <a class="nav-link ml-2" href="dashboard.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link ml-2" href="#">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link ml-2" href="#">Galery</a>
          </li>
          <li class="nav-item">
            <a class="nav-link ml-2" href="#">Profile</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- akhir nav bar -->

  <!-- awal content -->
  <div class="container">
    <div class="row">
      <div class="col col-10 col-lg-4 offset-lg-1 mt-3 align-self-center">
        <h1 class="">Edit Data</h1>
        <p class="mb-4">Fitur Ubah Ini, Berguna Untuk Merubah Data Nama, Alamat, Jumlah Galon Dan Yang Terpenting Jumlah Hutang..</p>
        <form action="" method="POST">
          <?php foreach ($query as $edites) : ?>
            <div class="form-group">
              <input type="hidden" name="id_pelangan" value="<?= $edites['id_pelangan'] ?>">
              <label for="formGroupExampleInput">Nama</label>
              <input type="text" name="nama" class="form-control" id="formGroupExampleInput" value="<?= $edites['nama'] ?>" autocomplete="off">
            </div>
            <div class="form-group">
              <label for="formGroupExampleInput2">Alamat</label>
              <input type="text" name="alamat" class="form-control" id="formGroupExampleInput2" value="<?= $edites['alamat'] ?>" autocomplete="off">
            </div>
            <div class="form-group">
              <label for="formGroupExampleInput2">Jumlah Galon</label>
              <input type="text" name="jml_galon" class="form-control" id="formGroupExampleInput2" value="<?= $edites['jml_galon'] ?>" autocomplete="off">
            </div>
            <div class="form-group">
              <label for="formGroupExampleInput2">Hutang</label>
              <input type="text" name="hutang" class="form-control" id="formGroupExampleInput2" value="<?= $edites['hutang'] ?>" autocomplete="off">
            </div>
            <button type="submit" name="submit" class="btn btn-dark mt-3">Tambah </button>
          <?php endforeach; ?>
        </form>
      </div>
      <div class="col col-sm-6 col-md-5 col-lg-4 d-none d-sm-block offset-1">
        <a href="http://"> <img src="img/dex.jpg" alt=""> </a>
      </div>
    </div>
    <!-- akhir kontent -->

    <!-- awal footer -->
    <div class="row">
      <div class="col mt-sm-0 mt-4 ">
        <hr class="mt-5 border border-dark">
      </div>
    </div>
    <div class="row">
      <div class="col text-center mt-2 mb-2">
        <h5>CopyRight@YogiPrayoga.AllReceved.</h5>
      </div>
    </div>

    <!-- akhir footer -->
  </div>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

  <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
</body>

</html>