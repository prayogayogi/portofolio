<?php
session_start();
if (!isset($_SESSION["login"])) {
  header('Location:index.php');
  exit;
}
require 'koneksi.php';
$id = $_GET["id"];
$delete = data("DELETE FROM db_pelangan WHERE id_pelangan = $id");

if ($delete) {
  header('Location:dashboard.php');
}
