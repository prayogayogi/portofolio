<?php
// koneksi ke data base
$conn = mysqli_connect("Localhost", "root", "", "echo");
if (!$conn) {
  echo "gagal koneksi.!!";
}

// function untuk pengulangan
function query($query)
{
  global $conn;
  $hasil = mysqli_query($conn, $query);
  $rows = [];
  while ($row = mysqli_fetch_assoc($hasil)) {
    $rows[] = $row;
  }
  return $rows;
}

// function untuk menmbah data
function data($query)
{
  global $conn;
  $hasil = mysqli_query($conn, $query);
  return $hasil;
}

// function untuk mencari data
function cari($kyword)
{
  $query = ("SELECT * FROM db_pelangan WHERE nama LIKE '%$kyword%' OR alamat LIKE '%$kyword%'");
  return query($query);
}

// function untuk menambah data user login
function register($data)
{
  global $conn;
  // menangkap inputan dari form registrasi 
  $username = strtolower(stripslashes($data["username"]));
  $password = htmlspecialchars(mysqli_real_escape_string($conn, $data["password"]));
  $password2 = htmlspecialchars(mysqli_real_escape_string($conn, $data["password2"]));

  // mengecek username sudah ada yang pakai atau belum
  $query = "SELECT username FROM user WHERE username = '$username'";
  $result = mysqli_query($conn, $query);
  if (mysqli_fetch_assoc($result)) {
    echo "<script>
          alert('Username Sudah Ada');
          </script>";
    return false;
  }

  // cek konfirmasi password sama dengan password 2 atau tidak
  if ($password !== $password2) {
    echo "<script>
    alert('Password Harus Sama');
    </script>";
    return false;
  }

  // enkripsi password
  $password = password_hash($password, PASSWORD_DEFAULT);

  // query simpan
  $query = "INSERT INTO user (username, password) VALUES ('$username','$password')";
  mysqli_query($conn, $query);
  return mysqli_affected_rows($conn);
}
