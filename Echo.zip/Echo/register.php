<?php
require 'koneksi.php';
if (isset($_POST["submit"])) {
  if (register($_POST) > 0) {
    echo "<script>
        alert('berhasil di tambahkan');
        document.location.href='index.php';
        </script>";
  } else {
    echo mysqli_error($conn);
  }
}
?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">
  <title>Registrasi | User Baru</title>
</head>

<body>
  <section class="login">
    <div class="container">
      <div class="row mt-5">
        <div class="col col-lg-6 mt-lg-5">
          <div class="card mt-lg-5" style="width: 30rem;">
            <img src="img/122.jpg" class="card-img-top img-thumbnail" alt="...">
          </div>
        </div>
        <div class="col col-lg-5 mt-3 mr-5 align-self-center">
          <h2>
            Hello,<br>Silahkan Registrasi
          </h2>
          <form class="mr-5 mb-5" method="POST" action="">
            <div class="form-group mt-lg-4">
              <label for="exampleInputEmail1">Username</label>
              <input type="text" class="form-control" name="username" id="exampleInputEmail1" aria-describedby="emailHelp" autocomplete="off" placeholder="Masukan Username">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Password</label>
              <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Masukan Password">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword2">Konfirmasi Password</label>
              <input type="password" class="form-control" name="password2" id="exampleInputPassword2" placeholder="Masukan Konfirmasi Password">
            </div>
            <button type="submit" class="btn btn-primary mt-4" name="submit">Submit</button>
            <p class="mt-3">Sudah Mempunyai Akun.? <a href="index.php">Login...!!</a></p>
          </form>
        </div>
      </div>
    </div>

  </section>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

</body>

</html>