<?php
// cek session
session_start();
if (!isset($_SESSION["login"])) {
  header('Location:index.php');
  exit;
}

// ekskusi mysqli
require 'koneksi.php';
$customer = query("SELECT * FROM db_pelangan");

// proses tambah data
if (isset($_POST["sumbit"])) {
  $nama = htmlspecialchars($_POST["nama"]);
  $alamat = htmlspecialchars($_POST["alamat"]);
  $jml_galon = htmlspecialchars($_POST["jml_galon"]);
  $hutang = htmlspecialchars($_POST["hutang"]);
  $post = data("INSERT INTO db_pelangan (nama,alamat,jml_galon,hutang) 
          VALUE
          ('$nama','$alamat','$jml_galon','$hutang')");
  if ($post) {
    echo "
        <script>
          document.location.href='dashboard.php';
        </script>
        ";
  }
}


?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
  <link rel="stylesheet" href="style.css">
  <title>Dashboard | </title>
</head>

<body>

  <!-- awal nav bar -->
  <nav class="navbar navbar-expand-lg navbar-light navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="dashboard.php">ECHO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav ">
          <li class="nav-item ">
            <a class="nav-link ml-lg-5" href="dashboard.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link ml-lg-2" href="#">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link ml-lg-2" href="#">Galery</a>
          </li>
          <li class="nav-item">
            <a class="nav-link ml-lg-2" href="#">Profile</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- akhir nav bar -->

  <!-- awal carousel -->
  <div class="container">
    <div class="row mt-5">
      <div class="col col-12 col-lg-6 mt-lg-5">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="img/12.jpg" class="d-block w-100 img-thumbnail" alt="...">
            </div>
            <div class="carousel-item">
              <img src="img/13.jpg" class="d-block w-100 img-thumbnail" alt="...">
            </div>
            <div class="carousel-item">
              <img src="img/14.jpg" class="d-block w-100 img-thumbnail" alt="...">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>
      <div class="col col-12 col-lg-5 ml-lg-5 mt-lg-5 ">
        <div class="container">
          <h4 class="mt-4 mt-lg-0">Tambah Pelanggan</h4>

          <!-- proses tambah  -->
          <form method="POST" action="">
            <div class="form-group">
              <label for="formGroupExampleInput">Nama</label>
              <input type="text" name="nama" class="form-control" id="formGroupExampleInput" placeholder="Masukkan Nama..." autocomplete="off">
            </div>
            <div class="form-group">
              <label for="formGroupExampleInput2">Alamat</label>
              <input type="text" name="alamat" class="form-control" id="formGroupExampleInput2" placeholder="Masukkan Alamat..." autocomplete="off">
            </div>
            <div class="form-group">
              <label for="formGroupExampleInput2">Jumlah Pinjam Galon</label>
              <input type="text" name="jml_galon" class="form-control" id="formGroupExampleInput2" placeholder="Jumlah Pinjam Galon..." autocomplete="off">
            </div>
            <div class="form-group">
              <label for="formGroupExampleInput2">Hutang</label>
              <input type="text" name="hutang" class="form-control" id="formGroupExampleInput2" placeholder="Jumlah Hutang..." autocomplete="off">
            </div>
            <button type="submit" name="sumbit" class="btn btn-dark mt-2 mb-4">Tambah </button>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- akhir carausel -->

  <!-- awal -->
  <div class="container">
    <div class="row text-center mt-5">
      <div class="col mt-3">
        <i class="far fa-address-book"></i>
      </div>
      <div class="col">
        <i class="fab fa-app-store"></i>
      </div>
      <div class="col">
        <i class="fas fa-atom"></i>
      </div>
      <div class="col mt-3">
        <i class="fas fa-car-alt w-100"></i>
      </div>
    </div>
  </div>
  <!-- akhir -->

  <!-- awal -->
  <div class="container">
    <div class="row mt-lg-5">
      <div class="col col-6 col-md-4 col-lg-3 mt-5 mt-lg-2">
        <h2 class="mt-lg-5">Echo Mineral</h2>
      </div>
      <div class="col col-6 col-md-4 col-lg-3">
        <h4>Kontak</h4>
        <a href="http://">
          <p>Eko Kondim</p>
        </a>
        <a href="http://">
          <p>Angga Pelo</p>
        </a>
        <a href="http://">
          <p>Tejo Supro</p>
        </a>
        <a href="http://">
          <p>Asep pear</p>
        </a>
      </div>
      <div class="col col-6 col-md-4 col-lg-3">
        <h4>Galery</h4>
        <a href="http://">
          <p>Depot galon</p>
        </a>
        <a href="http://">
          <p>Bersih-Bersih Depot</p>
        </a>
        <a href="http://">
          <p>Mobil</p>
        </a>
        <a href="http://">
          <p>Jalan-Jalan</p>
        </a>
        <a href="http://">
          <p>Angota</p>
        </a>
      </div>
      <div class="col col-6 col-md-3 col-lg-3 ">
        <h4>Saran</h4>
        <a href="http://">
          <p>Masukan</p>
        </a>
        <a href="http://">
          <p>Keritiakn</p>
        </a>
        <a href="http://">
          <p>Donasi</p>
        </a>
        <a href="http://">
          <p>Suport</p>
        </a>
      </div>
    </div>
    <div class="row">
      <div class="col mt-sm-0 mt-4 ">
        <hr class="mt-5 border border-dark">
      </div>
    </div>
    <div class="row">
      <div class="col text-center mt-2 mb-2">
        <h5>CopyRight@YogiPrayoga.AllReceved.</h5>
      </div>
    </div>

    <!-- akhir -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

</body>

</html>